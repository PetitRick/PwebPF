package rpg.ifgoiano.rpg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rpg.ifgoiano.rpg.entidade.Produto;
import rpg.ifgoiano.rpg.repositorio.ProdRepositorio;

@Service
public class ProdServiceImpl implements ProdService{
    
    static List<Produto> pers = new ArrayList<Produto>();
    
    @Autowired
    private ProdRepositorio prodRepositorio;

    @Override
    public List<Produto> listarProdutos() {
        return prodRepositorio.findAll();
    }

    public void inserir(Produto produto) {
        this.prodRepositorio.save(produto);
      
    }

    public Produto obterProduto(Long id){
		return this.prodRepositorio.getReferenceById(id);
    }

    @Override
	public void alterar(Produto produto) {
		this.prodRepositorio.save(produto);		
	}   
	
    @Override
	public void deletar(Long id) {
		this.prodRepositorio.deleteById(id);
	}
    

    
}
