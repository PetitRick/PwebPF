package rpg.ifgoiano.rpg.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import rpg.ifgoiano.rpg.entidade.Produto;

@Repository
public interface ProdRepositorio extends JpaRepository<Produto, Long> {
	
}