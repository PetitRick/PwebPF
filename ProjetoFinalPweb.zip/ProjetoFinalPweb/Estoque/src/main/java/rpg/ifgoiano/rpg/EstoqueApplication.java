package rpg.ifgoiano.rpg;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import rpg.ifgoiano.rpg.entidade.Produto;
import rpg.ifgoiano.rpg.repositorio.ProdRepositorio;

@SpringBootApplication
public class EstoqueApplication implements CommandLineRunner{
    
    @Autowired
    private ProdRepositorio prodRepositorio;

	public static void main(String[] args) {
		SpringApplication.run(EstoqueApplication.class, args);
	}
	
	public void run(String... args) throws Exception {
		Produto produto = new Produto();
		produto.setMarca("Nike");
		produto.setModelo("Air Jordan");
		produto.setCor("vermelho");	
		produto.setTamanho(40);
		produto.setQuantidade(10);
		
		prodRepositorio.save(produto);
    }

}
