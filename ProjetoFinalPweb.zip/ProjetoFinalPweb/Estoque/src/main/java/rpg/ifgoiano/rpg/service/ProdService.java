package rpg.ifgoiano.rpg.service;

import java.util.List;
import rpg.ifgoiano.rpg.entidade.Produto;


public interface ProdService {
    public void inserir(Produto produto);

    public Produto obterProduto(Long id);

	public void alterar(Produto produto);

	List<Produto> listarProdutos();

	void deletar(Long id);
}
